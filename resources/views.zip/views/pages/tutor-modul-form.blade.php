<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LD Indonesia</title>
<link rel="icon" type="image/jpeg" href="{{ asset('images/logo-ld.jpeg') }}">
<meta name="description" content="Form tambah modul pembelajaran atau simulasi baru — LD Indonesia.">
<meta name="robots" content="noindex, nofollow">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root{
  --navy: #1E2A47;
  --navy-soft: #435172;
  --pink: #EC4E8C;
  --pink-dark: #D63D79;
  --pink-light: #FDEAF1;
  --pink-pale: #FFF4F8;
  --purple: #7C6FE0;
  --gold: #D4A017;
  --maroon: #5C3620;
  --red: #E0483F;
  --red-bg: #FDECEA;
  --green: #2C9E6C;
  --green-bg: #DEF4E8;
  --gray-50: #FAF9F7;
  --gray-100: #F3F1EE;
  --gray-200: #E7E4E0;
  --gray-300: #D8D4CE;
  --gray-400: #9B9691;
  --gray-500: #7C776F;
  --gray-600: #6B675F;
  --gray-800: #3A362F;
  --white: #FFFFFF;

  --font-display: 'Baloo 2', 'Inter', sans-serif;
  --font-body: 'Inter', sans-serif;

  --radius-sm: 10px;
  --radius-md: 16px;
  --radius-lg: 20px;
  --radius-pill: 999px;
  --shadow-sm: 0 2px 8px rgba(30,42,71,0.06);
  --shadow-md: 0 10px 30px rgba(30,42,71,0.08);

  --sidebar-w: 268px;
  --topbar-h: 96px;
}

body{
  font-family: var(--font-body);
  color: var(--gray-800);
  background: var(--gray-50);
  line-height: 1.55;
  -webkit-font-smoothing: antialiased;
}
img, svg { display: block; max-width: 100%; }
a { color: inherit; text-decoration: none; }
button { font: inherit; cursor: pointer; border: none; background: none; }
:focus-visible{ outline: 3px solid var(--purple); outline-offset: 2px; border-radius: 4px; }
h1, h2 { font-family: var(--font-display); color: var(--navy); font-weight: 700; }

.skip-link{ position: absolute; left: -999px; top: 0; background: var(--navy); color: #fff; padding: 12px 20px; z-index: 300; border-radius: 0 0 8px 0; }
.skip-link:focus{ left: 0; }

@media (prefers-reduced-motion: reduce){
  *, *::before, *::after { animation-duration: 0.001ms !important; transition-duration: 0.001ms !important; }
}

/* ============ APP SHELL ============ */
.app-shell{ 
  display: flex; 
  min-height: 100vh; 
  width: 100%;
}

.sidebar{
  width: var(--sidebar-w);
  flex-shrink: 0;
  background: linear-gradient(180deg, var(--pink-pale) 0%, #FDF1F6 100%);
  border-right: 1px solid var(--gray-200);
  display: flex;
  flex-direction: column;
  position: sticky;
  top: 0;
  height: 100vh;
  z-index: 60;
}
.sidebar-brand{ display: flex; align-items: center; gap: 10px; padding: 26px 24px; border-bottom: 1px solid rgba(30,42,71,0.06); }
.brand-mark{ width: 40px; height: 40px; flex-shrink: 0; }
.brand-text{ display: flex; flex-direction: column; line-height: 1.15; }
.brand-text strong{ font-family: var(--font-display); font-weight: 800; font-size: 1.02rem; color: var(--navy); }
.brand-text strong span{ color: var(--pink); }
.brand-text small{ font-size: 0.66rem; color: var(--gray-600); font-weight: 500; }

.sidebar-nav{ flex-grow: 1; padding: 20px 16px; }
.sidebar-nav ul{ list-style: none; display: flex; flex-direction: column; gap: 6px; }
.nav-link{
  display: flex; align-items: center; gap: 14px; padding: 13px 16px;
  border-radius: var(--radius-sm); font-weight: 700; font-size: 0.96rem; color: var(--navy-soft);
  transition: background 0.15s ease, color 0.15s ease;
}
.nav-link svg{ width: 21px; height: 21px; flex-shrink: 0; }
.nav-link:hover{ background: rgba(236,78,140,0.08); color: var(--pink-dark); }
.nav-link.active{ background: var(--white); color: var(--pink-dark); box-shadow: var(--shadow-sm); }

.sidebar-footer{ padding: 20px 16px 26px; border-top: 1px solid rgba(30,42,71,0.06); }
.logout-link{ display: flex; align-items: center; gap: 14px; padding: 13px 16px; border-radius: var(--radius-sm); font-weight: 700; font-size: 0.96rem; color: var(--navy-soft); }
.logout-link:hover{ background: rgba(224,72,63,0.08); color: #C8392F; }
.logout-link svg{ width: 21px; height: 21px; }

.sidebar-close{ display: none; }

.main-col{ 
  flex: 1 1 0%; 
  min-width: 0; 
  display: flex; 
  flex-direction: column; 
}

.topbar{
  height: var(--topbar-h);
  display: flex; align-items: center; justify-content: flex-end; gap: 16px;
  padding: 0 40px;
  background: linear-gradient(115deg, #FCEFD9 0%, #FDE4EE 55%, #FBCFE0 100%);
  position: sticky; top: 0; z-index: 40;
}
.menu-toggle{ display: none; width: 40px; height: 40px; align-items: center; justify-content: center; border-radius: var(--radius-sm); margin-right: auto; color: var(--navy); }
.menu-toggle:hover{ background: rgba(255,255,255,0.5); }

.page-content{ 
  padding: 32px 40px 60px; 
  max-width: 1180px; 
  width: 100%; 
  margin: 0 auto; 
  box-sizing: border-box;
  overflow-x: hidden;
}

.back-link{
  display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 13px 22px;
  border-radius: var(--radius-pill); border: 1.5px solid var(--pink-light); color: var(--pink-dark);
  font-weight: 700; font-size: 0.94rem;
}
.back-link:hover{ background: var(--pink-pale); }
.back-link svg{ width: 16px; height: 16px; }

.page-heading{ margin-bottom: 22px; }
.page-heading h1{ font-size: 1.6rem; }

/* ============ FORM PANEL ============ */
.form-panel{
  background: var(--white); border-radius: var(--radius-lg); box-shadow: var(--shadow-md);
  border: 1px solid var(--gray-100); padding: 32px 34px;
  width: 100%; max-width: 100%; box-sizing: border-box;
}
.form-grid{ display: grid; grid-template-columns: 1.15fr 0.85fr; gap: 40px; width: 100%; min-width: 0; }

.field{ margin-bottom: 24px; min-width: 0; }
.field label{ display: block; font-family: var(--font-display); font-weight: 700; font-size: 1.02rem; color: var(--navy); margin-bottom: 10px; }
.field input[type="text"], .field textarea{
  width: 100%; font: inherit; font-size: 0.94rem; padding: 13px 16px;
  border: 1.5px solid var(--gray-200); border-radius: var(--radius-sm); background: var(--white); color: var(--gray-800);
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}
.field input[type="text"]:focus, .field textarea:focus{ outline: none; border-color: var(--pink); box-shadow: 0 0 0 4px var(--pink-pale); }
.field textarea{ min-height: 190px; resize: vertical; font-family: var(--font-body); }
.field input[aria-invalid="true"], .field textarea[aria-invalid="true"]{ border-color: var(--red); }

.field-row{ display: grid; grid-template-columns: 1fr 1fr; gap: 20px; width: 100%; min-width: 0; }

.select-wrap{ position: relative; width: 100%; }
.select-wrap select{
  appearance: none; -webkit-appearance: none; width: 100%; font: inherit; font-size: 0.94rem;
  padding: 13px 42px 13px 16px; border: 1.5px solid var(--gray-200); border-radius: var(--radius-sm);
  background: var(--white); color: var(--gray-800); cursor: pointer;
}
.select-wrap select:invalid{ color: var(--gray-400); }
.select-wrap select:focus{ outline: none; border-color: var(--pink); box-shadow: 0 0 0 4px var(--pink-pale); }
.select-wrap svg{ position: absolute; right: 16px; top: 50%; transform: translateY(-50%); width: 16px; height: 16px; color: var(--gray-500); pointer-events: none; }
.select-wrap select[aria-invalid="true"]{ border-color: var(--red); }

.field-error{ display: none; align-items: center; gap: 6px; color: var(--red); font-size: 0.8rem; font-weight: 500; margin-top: 7px; }
.field-error.show{ display: flex; }
.field-error svg{ width: 14px; height: 14px; flex-shrink: 0; }

/* ---- Upload panel ---- */
.upload-panel-label{ font-family: var(--font-display); font-weight: 700; font-size: 1.02rem; color: var(--navy); margin-bottom: 10px; }
.dropzone{
  border: 1.5px dashed var(--gray-300); border-radius: var(--radius-md);
  min-height: 300px; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center;
  padding: 30px; transition: border-color 0.15s ease, background 0.15s ease; cursor: pointer; width: 100%; box-sizing: border-box;
}
.dropzone.is-dragover{ border-color: var(--pink); background: var(--pink-pale); }
.dropzone-icon{ width: 52px; height: 52px; color: var(--gray-400); margin-bottom: 16px; }
.dropzone-title{ font-weight: 700; font-size: 0.96rem; color: var(--navy); margin-bottom: 6px; }
.dropzone-or{ font-size: 0.86rem; color: var(--gray-400); margin-bottom: 14px; }
.dropzone-btn{
  background: var(--pink-pale); color: var(--pink-dark); font-weight: 700; font-size: 0.9rem;
  padding: 10px 26px; border-radius: var(--radius-pill); cursor: pointer;
  display: inline-block;
}
.dropzone-btn:hover{ background: var(--pink-light); }
.upload-hint{ font-size: 0.82rem; color: var(--gray-500); margin-top: 12px; }

.file-chip{
  display: none; align-items: center; gap: 12px; margin-top: 16px;
  background: var(--green-bg); border: 1px solid #B7E4CB; border-radius: var(--radius-sm); padding: 12px 16px;
  width: 100%; box-sizing: border-box;
}
.file-chip.show{ display: flex; }
.file-chip svg{ width: 20px; height: 20px; color: var(--green); flex-shrink: 0; }
.file-chip-name{ flex-grow: 1; font-size: 0.86rem; font-weight: 600; color: var(--navy); word-break: break-all; }
.file-chip-remove{ color: var(--gray-500); flex-shrink: 0; cursor: pointer; }
.file-chip-remove:hover{ color: var(--red); }
.file-chip-remove svg{ width: 16px; height: 16px; color: inherit; }

.upload-skip-note{
  display: none; align-items: flex-start; gap: 10px;
  background: var(--pink-pale); border: 1px solid var(--pink-light); border-radius: var(--radius-md);
  padding: 18px 20px; font-size: 0.88rem; color: var(--gray-600); line-height: 1.6;
}
.upload-skip-note.show{ display: flex; }
.upload-skip-note svg{ width: 18px; height: 18px; color: var(--pink-dark); flex-shrink: 0; margin-top: 1px; }

/* ============ FOOTER ACTIONS ============ */
.form-actions{ display: flex; align-items: center; justify-content: space-between; gap: 16px; margin-top: 30px; flex-wrap: wrap; width: 100%; }
.btn-next{
  display: inline-flex; align-items: center; justify-content: center; gap: 8px;
  padding: 14px 30px; border-radius: var(--radius-pill);
  background: linear-gradient(135deg, var(--pink) 0%, var(--pink-dark) 100%); color: var(--white);
  font-weight: 700; font-size: 0.96rem; box-shadow: 0 12px 28px rgba(236,78,140,0.22);
  transition: transform 0.18s ease; cursor: pointer;
}
.btn-next:hover{ transform: translateY(-2px); }
.btn-next svg{ width: 17px; height: 17px; }

/* ============ RESPONSIVE BREAKPOINTS ============ */
@media (max-width: 980px){
  .sidebar{ position: fixed; left: 0; top: 0; transform: translateX(-100%); transition: transform 0.22s ease; box-shadow: var(--shadow-md); }
  .sidebar.open{ transform: translateX(0); }
  .sidebar-close{ display: flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 8px; margin-left: auto; color: var(--navy); }
  .sidebar-close:hover{ background: rgba(30,42,71,0.06); }
  .sidebar-brand{ justify-content: space-between; }
  .menu-toggle{ display: flex; }
  .topbar{ padding: 0 20px; }
  .page-content{ padding: 24px 16px 48px; }
  .backdrop{ display: none; position: fixed; inset: 0; background: rgba(30,42,71,0.35); z-index: 50; }
  .backdrop.show{ display: block; }
  .form-panel{ padding: 22px 20px; }
  .form-grid{ grid-template-columns: 1fr; gap: 24px; }
  .field-row{ grid-template-columns: 1fr; gap: 0; }
}

@media (max-width: 640px){
  .page-content{
    padding: 16px 12px 36px;
  }
  .page-heading h1{
    font-size: 1.35rem;
  }
  .form-panel{
    padding: 18px 14px;
  }
  .field{
    margin-bottom: 18px;
  }
  .field label,
  .upload-panel-label{
    font-size: 0.94rem;
    margin-bottom: 6px;
  }
  .field input[type="text"],
  .field textarea,
  .select-wrap select{
    padding: 11px 14px;
    font-size: 0.9rem;
  }
  .dropzone{
    min-height: 220px;
    padding: 20px 14px;
  }
  .dropzone-icon{
    width: 42px;
    height: 42px;
    margin-bottom: 10px;
  }
  .form-actions{
    flex-direction: column-reverse;
    gap: 12px;
    margin-top: 24px;
  }
  .back-link,
  .btn-next{
    width: 100%;
  }
}
</style>
</head>
<body>
<a href="#mainContent" class="skip-link">Langsung ke konten utama</a>

<div class="app-shell">
  <div class="backdrop" id="backdrop"></div>

  <!-- ============ SIDEBAR ============ -->
  <x-sidebar.tutor />

  <!-- ============ MAIN ============ -->
  <div class="main-col">
    <x-header.tutor />

    <main class="page-content" id="mainContent">
      <div class="page-heading">
        <h1>{{ isset($module) ? 'Edit Modul' : 'Tambah Modul' }}</h1>
      </div>

      @if ($errors->any())
        <div style="margin-bottom: 20px; padding: 16px 18px; border-radius: 12px; background: var(--red-bg); border: 1px solid #f5c2c0; color: var(--red);">
          <strong>Form belum dapat disimpan:</strong>
          <ul style="margin: 8px 0 0 20px;">
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
          </ul>
        </div>
      @endif

      <form
        class="form-panel"
        id="modulForm"
        action="{{ isset($module) ? route('modul.update', $module) : route('modul.store') }}"
        method="POST"
        enctype="multipart/form-data"
        novalidate
      >
        @csrf
        @if(isset($module))
          @method('PUT')
        @endif

        <div class="form-grid">
          <!-- ============ KOLOM KIRI: DATA MODUL ============ -->
          <div>
            <div class="field">
              <label for="judulModul">Judul Modul</label>
              <input type="text" id="judulModul" name="judul" placeholder="Contoh: Artikel Der, Das, Die" value="{{ old('judul', $module->judul ?? '') }}" aria-describedby="judulError">
              <p class="field-error" id="judulError">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v5M12 16h.01"/></svg>
                <span>Judul modul wajib diisi.</span>
              </p>
            </div>

            <div class="field-row">
              <div class="field">
                <label for="levelModul">Level</label>
                <div class="select-wrap">
                  <select id="levelModul" name="level" required aria-describedby="levelError">
                    <option value="" disabled {{ old('level', $module->level ?? '') == '' ? 'selected' : '' }}>Pilih Level</option>
                    @foreach(['A1', 'A2', 'B1', 'B2'] as $lvl)
                      <option value="{{ $lvl }}" {{ old('level', $module->level ?? '') === $lvl ? 'selected' : '' }}>{{ $lvl }}</option>
                    @endforeach
                  </select>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
                </div>
                <p class="field-error" id="levelError">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v5M12 16h.01"/></svg>
                  <span>Pilih level modul.</span>
                </p>
              </div>

              <div class="field">
                <label for="kategoriModul">Kategori</label>
                <div class="select-wrap">
                  @php
                    $currentKategori = old('kategori', $module->kategori ?? '');
                    $kategoriOptions = [
                      'materi' => 'Materi',
                      'simulasi_horen' => 'Simulasi Hören',
                      'simulasi_lesen' => 'Simulasi Lesen',
                      'simulasi_schreiben' => 'Simulasi Schreiben',
                      'simulasi_sprechen' => 'Simulasi Sprechen'
                    ];
                  @endphp
                  <select id="kategoriModul" name="kategori" required aria-describedby="kategoriError">
                    <option value="" disabled {{ $currentKategori == '' ? 'selected' : '' }}>Pilih Kategori</option>
                    @foreach($kategoriOptions as $val => $label)
                      <option value="{{ $val }}" {{ $currentKategori === $val ? 'selected' : '' }}>{{ $label }}</option>
                    @endforeach
                  </select>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
                </div>
                <p class="field-error" id="kategoriError">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v5M12 16h.01"/></svg>
                  <span>Pilih kategori modul.</span>
                </p>
              </div>
            </div>

            <div class="field" style="margin-bottom:0;">
              <label for="deskripsiModul">Deskripsi</label>
              <textarea id="deskripsiModul" name="deskripsi" placeholder="Tuliskan deskripsi singkat mengenai modul ini...">{{ old('deskripsi', $module->deskripsi ?? '') }}</textarea>
            </div>
          </div>

          <!-- ============ KOLOM KANAN: UPLOAD FILE ============ -->
          <div>
            <div class="upload-panel-label" id="uploadLabel">Upload File PDF</div>

            <div class="dropzone" id="dropzone">
              <svg class="dropzone-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 18a4.5 4.5 0 0 1-1.4-8.8A5.5 5.5 0 0 1 16.3 7 4 4 0 0 1 17 15"/><path d="M12 12v8"/><path d="m9 15 3-3 3 3"/></svg>
              <div class="dropzone-title">Drag &amp; drop file di sini</div>
              <div class="dropzone-or">atau</div>
              <button type="button" class="dropzone-btn" id="chooseFileBtn">Pilih File</button>
              <input type="file" id="fileInput" name="file" accept=".pdf,application/pdf" hidden>
            </div>

            <div class="file-chip" id="fileChip">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
              <span class="file-chip-name" id="fileChipName"></span>
              <button type="button" class="file-chip-remove" id="fileChipRemove" aria-label="Hapus file">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>
              </button>
            </div>

            <p class="upload-hint" id="uploadHint">Format yang didukung: PDF. Maksimal 10 MB.</p>

            <!-- Muncul otomatis saat Kategori = salah satu Simulasi -->
            <div class="upload-skip-note" id="uploadSkipNote">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v5M12 16h.01"/></svg>
              <span>Upload file tidak diperlukan untuk kategori simulasi. Soal simulasi akan ditambahkan pada langkah berikutnya.</span>
            </div>
          </div>
        </div>

        <div class="form-actions">
          <a href="{{ route('modul.index') }}" class="back-link">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>
            Kembali
          </a>
          <button type="submit" class="btn-next" id="nextBtn">
            Selanjutnya
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
          </button>
        </div>
      </form>
    </main>
  </div>
</div>

<script>
(function(){
  "use strict";

  var kategoriSelect = document.getElementById('kategoriModul');
  var uploadLabel = document.getElementById('uploadLabel');
  var dropzone = document.getElementById('dropzone');
  var fileChip = document.getElementById('fileChip');
  var uploadHint = document.getElementById('uploadHint');
  var uploadSkipNote = document.getElementById('uploadSkipNote');
  var fileInput = document.getElementById('fileInput');
  var chooseFileBtn = document.getElementById('chooseFileBtn');
  var fileChipName = document.getElementById('fileChipName');
  var fileChipRemove = document.getElementById('fileChipRemove');
  var selectedFile = null;

  function isSimulasi(value){ 
    return value === 'simulasi_horen' || 
           value === 'simulasi_lesen' || 
           value === 'simulasi_schreiben' || 
           value === 'simulasi_sprechen'; 
  }

  function updateUploadVisibility(){
    var value = kategoriSelect.value;
    var showUpload = value === 'materi';
    var showSkipNote = isSimulasi(value);

    uploadLabel.style.display = showUpload ? 'block' : 'none';
    dropzone.style.display = showUpload ? 'flex' : 'none';
    uploadHint.style.display = showUpload ? 'block' : 'none';
    if (!showUpload) fileChip.classList.remove('show');
    else fileChip.classList.toggle('show', !!selectedFile);

    uploadSkipNote.classList.toggle('show', showSkipNote);
  }
  
  if (kategoriSelect) {
    kategoriSelect.addEventListener('change', updateUploadVisibility);
    updateUploadVisibility();
  }

  function setSelectedFile(file){
    selectedFile = file;
    if (file){
      fileChipName.textContent = file.name;
      fileChip.classList.add('show');
    } else {
      fileChip.classList.remove('show');
    }
  }

  if (chooseFileBtn && fileInput) {
    chooseFileBtn.addEventListener('click', function(e){
      e.stopPropagation();
      fileInput.click();
    });
  }

  if (dropzone && fileInput) {
    dropzone.addEventListener('click', function(e){
      if (e.target !== chooseFileBtn && !chooseFileBtn.contains(e.target)) {
        fileInput.click();
      }
    });
  }

  if (fileInput) {
    fileInput.addEventListener('change', function(){
      if (fileInput.files && fileInput.files[0]) setSelectedFile(fileInput.files[0]);
    });
  }
  
  if (fileChipRemove) {
    fileChipRemove.addEventListener('click', function(){
      setSelectedFile(null);
      fileInput.value = '';
    });
  }

  if (dropzone) {
    ['dragenter', 'dragover'].forEach(function(evt){
      dropzone.addEventListener(evt, function(e){
        e.preventDefault(); e.stopPropagation();
        dropzone.classList.add('is-dragover');
      });
    });
    ['dragleave', 'drop'].forEach(function(evt){
      dropzone.addEventListener(evt, function(e){
        e.preventDefault(); e.stopPropagation();
        dropzone.classList.remove('is-dragover');
      });
    });
    dropzone.addEventListener('drop', function(e){
      var files = e.dataTransfer && e.dataTransfer.files;
      if (files && files[0]) {
        fileInput.files = files;
        setSelectedFile(files[0]);
      }
    });
  }

  var form = document.getElementById('modulForm');
  var judulInput = document.getElementById('judulModul');
  var levelSelect = document.getElementById('levelModul');

  function setFieldError(inputId, errorId, show){
    var inputEl = document.getElementById(inputId);
    var errEl = document.getElementById(errorId);
    if (inputEl) inputEl.setAttribute('aria-invalid', show ? 'true' : 'false');
    if (errEl) errEl.classList.toggle('show', show);
  }

  if (form) {
    form.addEventListener('submit', function(e){
      var judulOk = judulInput.value.trim().length > 0;
      var levelOk = levelSelect.value !== '';
      var kategoriOk = kategoriSelect.value !== '';

      setFieldError('judulModul', 'judulError', !judulOk);
      setFieldError('levelModul', 'levelError', !levelOk);
      setFieldError('kategoriModul', 'kategoriError', !kategoriOk);

      if (!judulOk || !levelOk || !kategoriOk) {
        e.preventDefault();
      }
    });
  }

  var sidebar = document.getElementById('sidebar');
  var menuToggle = document.getElementById('menuToggle');
  var sidebarClose = document.getElementById('sidebarClose');
  var backdrop = document.getElementById('backdrop');

  function openSidebar(){ 
    if (sidebar) sidebar.classList.add('open'); 
    if (backdrop) backdrop.classList.add('show'); 
    if (menuToggle) menuToggle.setAttribute('aria-expanded', 'true'); 
  }

  function closeSidebar(){ 
    if (sidebar) sidebar.classList.remove('open'); 
    if (backdrop) backdrop.classList.remove('show'); 
    if (menuToggle) menuToggle.setAttribute('aria-expanded', 'false'); 
  }

  if (menuToggle) menuToggle.addEventListener('click', openSidebar);
  if (sidebarClose) sidebarClose.addEventListener('click', closeSidebar);
  if (backdrop) backdrop.addEventListener('click', closeSidebar);
})();
</script>
</body>
</html>